#!/usr/bin/env bash
set -euo pipefail

cd /app
python -m pytest tests/test_outputs.py
