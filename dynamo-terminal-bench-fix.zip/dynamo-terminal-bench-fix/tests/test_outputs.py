import json
import re
from pathlib import Path

ROOT = Path("/app")
LOG_PATH = ROOT / "access.log"
REPORT_PATH = ROOT / "report.json"

LOG_RE = re.compile(
    r'"(?P<method>[A-Z]+)\s+(?P<endpoint>\S+)\s+HTTP/[^\"]+"\s+'
    r'(?P<status>\d{3})\s+.*?\s+(?P<latency>\d+(?:\.\d+)?)ms'
)


def expected_values():
    total_requests = 0
    status_counts = {}
    endpoint_counts = {}
    latencies = []

    for line in LOG_PATH.read_text().splitlines():
        match = LOG_RE.search(line)
        if not match:
            continue

        total_requests += 1
        status = match.group("status")
        endpoint = match.group("endpoint")
        latency = float(match.group("latency"))

        status_counts[status] = status_counts.get(status, 0) + 1
        endpoint_counts[endpoint] = endpoint_counts.get(endpoint, 0) + 1
        latencies.append(latency)

    top_endpoint = sorted(endpoint_counts.items(), key=lambda x: (-x[1], x[0]))[0][0]
    average_latency_ms = round(sum(latencies) / len(latencies), 2)

    return {
        "total_requests": total_requests,
        "status_counts": dict(sorted(status_counts.items())),
        "top_endpoint": top_endpoint,
        "average_latency_ms": average_latency_ms,
    }


def load_report():
    assert REPORT_PATH.exists(), "report.json must exist at /app/report.json"
    return json.loads(REPORT_PATH.read_text())


def test_report_file_exists_and_is_valid_json():
    """Verifies success criterion 1: create /app/report.json as valid JSON."""
    load_report()


def test_total_requests():
    """Verifies success criterion 2: total_requests equals parsed request log entries."""
    report = load_report()
    expected = expected_values()
    assert report.get("total_requests") == expected["total_requests"]


def test_status_counts():
    """Verifies success criterion 3: status_counts contains exact HTTP status-code counts."""
    report = load_report()
    expected = expected_values()
    assert report.get("status_counts") == expected["status_counts"]


def test_top_endpoint():
    """Verifies success criterion 4: top_endpoint is most frequent endpoint, alphabetically first on ties."""
    report = load_report()
    expected = expected_values()
    assert report.get("top_endpoint") == expected["top_endpoint"]


def test_average_latency_ms():
    """Verifies success criterion 5: average_latency_ms is mean latency rounded to 2 decimals."""
    report = load_report()
    expected = expected_values()
    assert report.get("average_latency_ms") == expected["average_latency_ms"]
