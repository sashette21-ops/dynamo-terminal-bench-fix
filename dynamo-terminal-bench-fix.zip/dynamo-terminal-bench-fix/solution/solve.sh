#!/usr/bin/env bash
set -euo pipefail

python - <<'PY'
import json
import re
from pathlib import Path

log_path = Path('/app/access.log')
report_path = Path('/app/report.json')

pattern = re.compile(
    r'"(?P<method>[A-Z]+)\s+(?P<endpoint>\S+)\s+HTTP/[^\"]+"\s+'
    r'(?P<status>\d{3})\s+.*?\s+(?P<latency>\d+(?:\.\d+)?)ms'
)

total_requests = 0
status_counts = {}
endpoint_counts = {}
latencies = []

for line in log_path.read_text().splitlines():
    match = pattern.search(line)
    if not match:
        continue

    total_requests += 1
    status = match.group('status')
    endpoint = match.group('endpoint')
    latency = float(match.group('latency'))

    status_counts[status] = status_counts.get(status, 0) + 1
    endpoint_counts[endpoint] = endpoint_counts.get(endpoint, 0) + 1
    latencies.append(latency)

top_endpoint = sorted(endpoint_counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
average_latency_ms = round(sum(latencies) / len(latencies), 2)

report = {
    'total_requests': total_requests,
    'status_counts': dict(sorted(status_counts.items())),
    'top_endpoint': top_endpoint,
    'average_latency_ms': average_latency_ms,
}

report_path.write_text(json.dumps(report, indent=2) + '\n')
PY
